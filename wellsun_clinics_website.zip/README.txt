WELLSUN CLINICS WEBSITE
========================
This is a responsive single-page website inspired by the structure and clean healthcare presentation of nihahealth.in, but written specifically for Wellsun Clinics.

Files:
- index.html — complete website

To publish:
1. Upload index.html to Netlify, Vercel, GitHub Pages, or your existing hosting.
2. Connect your domain if you have one.

Important:
- The content uses information currently visible on the Wellsun Grexa page.
- Replace/add doctor names, logo, photos, services, test list, WhatsApp link and social links if you provide them.
